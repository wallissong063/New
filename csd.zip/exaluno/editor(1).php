<?php
// Define o arquivo de dados
$arquivo = 'dados.txt';

// Lê o arquivo de dados e armazena as linhas em um array
$linhas = file($arquivo);

// Obtém o ID da linha a ser editada
$id = isset($_GET['id']) ? (int) $_GET['id'] : -1;

// Verifica se o ID é válido e se a linha existe
if ($id >= 0 && isset($linhas[$id])) {
  // Divide a linha em campos
  list($nome, $nota1, $nota2, $multi, $nota3, $faltas) = explode(";", trim($linhas[$id]));

  // Verifica se o formulário foi enviado
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtém os novos valores dos campos
    $novo_nome = $_POST['nome'];
    $nova_nota1 = $_POST['nota1'];
    $nova_nota2 = $_POST['nota2'];
    $nova_multi = $_POST['multi'];
    $nova_nota3 = $_POST['nota3'];
    $nova_faltas = $_POST['faltas'];

    // Atualiza a linha com os novos valores
    $linhas[$id] = "$novo_nome;$nova_nota1;$nova_nota2;$nova_multi;$nova_nota3;$nova_faltas\n";

    // Salva as alterações no arquivo
    file_put_contents($arquivo, implode('', $linhas));

    // Redireciona para a página de leitura
    header("Location: leitor.php");
    exit;
  }
} else {
  // Se o ID for inválido, exibe uma mensagem de erro
  die("Linha inválida!");
}
?>

<!-- HTML para exibir o formulário de edição -->
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../style.css">
  <meta charset="UTF-8">
  <title>Editar Linha</title>
</head>
<body>
  <style>
   * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    input{
        padding: 10px;
        box-shadow: 5px 5px 5px 5px;
    }
    input:hover{
        box-shadow: none;
    }
    </style>
  <header style="width: 100%; background-color: dimgray; color: white;">
    <h1>
      <ul>
        <li><div style=" display: flex; ">
          <!-- Logo da aplicação -->
          <img src="../source/logo.png" width="40px"> CLASS DATA
       </div> </li>
      </ul>
    </h1>
    <!-- Link para voltar ao painel -->
    <a href="../painel.php" style="color: white;">voltar</a>
  </header> <br><br>
  <div style=" margin: auto; border: 1px solid white; backdrop-filter: blur(20px); padding: 5%; width: 40%; color: antiquewhite; border-radius: 10px; ">
  <h1>aluno numero <?= $id + 1 ?></h1>
  <form  method="post">
    aluno <br> <input type="text" name="nome" value="<?= htmlspecialchars($nome) ?>"><br>
    <div style="display: flex; margin: 0 auto; justify-content: center;">
    <div style="display: inline-block; padding: 40px;">nota 1 etapa <br> <input type="number" name="nota1" max="25" min="0" value="<?= htmlspecialchars($nota1) ?>"></div>
    <div style="display: inline-block; padding: 40px;">nota 2 etapa <br> <input type="number" name="nota2" max="25" min="0" value="<?= htmlspecialchars($nota2) ?>"></div></div><br>
  <div style=" justify-content: center; display: flex;">
    <div style="display: inline-block; padding: 40px;">prova multi <br> <input type="number" name="multi" max="15" min="0" value="<?= htmlspecialchars($multi) ?>"></div>
    <div style="display: inline-block; padding: 40px;">nota 3 etapa <br> <input type="number" name="nota3" max="30" min="0" value="<?= htmlspecialchars($nota3) ?>"></div></div><br>
    faltas <br> <input type="number" name="faltas" min="0" value="<?= htmlspecialchars($faltas) ?>" required><br><br>
    <button class="click" type="submit">Salvar</button>
  </form></div>
  <br>
  <a href="leitor.php">Voltar</a>
</body>
</html>