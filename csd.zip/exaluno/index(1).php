
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../style.css">
    <style>
        input{
            border-radius: 10px;
            padding: 10px;
        }
    </style>
    <title>Login</title>
</head>
<body style="justify-content: center; color: aliceblue;" >
    <h2>CSD</h2>
        <p class="pr">class data</p>
   
    <form method="post" action="../login.php"><div style="font-size: 20px;">
        <label>nome:</label> <br>
        <input type="text" name="usuario" required><br><br>
        <label>Senha:</label><br>
        <input type="password" name="senha" required><br><br>
        <button class="click" type="submit">Entrar</button>
    </div></form>
</body>
</html>