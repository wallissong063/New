<?php
// Lê o arquivo 'dados.txt' e armazena as linhas em um array
$linhas = file('dados.txt');
?>

<!-- HTML para exibir os dados dos alunos -->
<!DOCTYPE html>
<html>
<head>
  <!-- Link para o arquivo de estilo CSS -->
  <link rel="stylesheet" href="../style.css">
  <meta charset="UTF-8">
  <title>dados dos alunos</title>
  <style>
    /* Estilos para a tabela e elementos */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    table {
      border-collapse: collapse;
    }
    th, td {
      padding: 8px;
      border: 1px solid #ccc;
    }
    .correcao {
      color: orange;
      font-size: 12px;
    }
    .erro {
      color: red;
      font-size: 12px;
    }
  </style>
</head>
<body style="background-color: aquamarine;">
  <!-- Cabeçalho com logo e link para voltar -->
  <header style="width: 100%; background-color: dimgray; color: white;">
    <h1>
      <ul>
        <li><div style=" display: flex; ">
          <!-- Logo da aplicação -->
          <img src="../source/logo.png" width="40px"> CLASS DATA
       </div> </li>
      </ul>
    </h1>
    <!-- Link para voltar ao painel -->
    <a href="../painel.php" style="color: white;">voltar</a>
  </header>
  <h1 style="color: white;">DADOS DOS ALUNOS</h1>
  <!-- Tabela para exibir os dados dos alunos -->
   <div style="justify-content: center; display: flex;">
  <table>
     <?php /*
      $alunos = file('dados.txt');
      foreach ($alunos as $valor) {
        echo $valor;
      }
      //$paluno = $_POST ['paluno'];
      $busca = str_contains( $alunos,'Wallisson');
      if (empty($busca)) {
        echo "oiii";
      }else{
        echo $busca;
      } */
     ?>
     <th colspan="9" >
      <h3>
        engenharia de software
      </h3>
    </th>
     
    <tr>
      <th>Nome</th>
      <th>nota <br> 1 etapa</th>
      <th>nota <br> 2 etapa </th>
      <th>prova multi</th>
      <th>nota <br> 3 etapa </th>
      <th>total</th>
      <th>estado</th>
      <th>faltas</th>
      <th>edição</th>
    </tr>
    <?php foreach ($linhas as $index => $linha): ?>
      <?php
      // Divide a linha em campos
      $campos = explode(";", trim($linha));
      if (count($campos) === 6) {
        // Atribui os valores dos campos às variáveis
        list($nome, $nota1, $nota2, $multi, $nota3, $faltas) = $campos;
        $msg = '';
      }
      ?>
      <?php
      // Calcula o total e a média
      $total = ($nota1 + $nota2 + $multi + $nota3);
      // Verifica se o aluno está aprovado ou em recuperação
      if ($total <= 59) {
        $media = "recuperação";
      } else {
        $media = "aprovado";
      }
      ?>
      <tr>
        <!-- Exibe os dados do aluno -->
        <td><?= htmlspecialchars($nome) ?></td>
        <td><?= htmlspecialchars($nota1) ?></td>
        <td><?= htmlspecialchars($nota2) ?></td>
        <td><?= htmlspecialchars($multi) ?></td>
        <td><?= htmlspecialchars($nota3) ?></td>
        <td><?= htmlspecialchars($total) ?></td>
        <td><?= htmlspecialchars($media) ?></td>
        <td style="color: red;" ><?= htmlspecialchars($faltas) ?></td>
        <td>
          <!-- Link para editar os dados do aluno -->
          <a style="text-decoration: none; color: blue;" href="editor.php?id=<?= $index ?>">editar</a><br>
          <?= $msg ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</body>
</html>