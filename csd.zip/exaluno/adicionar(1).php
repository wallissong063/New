<html> 
<head> 
<title>csd</title>
<META="UTF-8">
<link rel="stylesheet" href="../style.css">
</head>
<body style="color: white;" >
    
  <style>
   * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    input{
        padding: 10px;
        box-shadow: 5px 5px 5px 5px;
    }
    input:hover{
        box-shadow: none;
    }
    select{
        padding: 10px;
        border-radius: 5px;
    }
    </style>
  <header style="width: 100%; background-color: dimgray; color: white;">
    <h1>
      <ul>
        <li><div style=" display: flex; ">
          <!-- Logo da aplicação -->
          <img src="../source/logo.png" width="40px"> CLASS DATA
       </div> </li>
      </ul>
    </h1>
    <!-- Link para voltar ao painel -->
    <a style="text-decoration: none;" href="../painel.php" style="color: white;">voltar</a>
  </header> <br><br><br>
<h1> ADICIONAR ATIVIDADES</h1>
<div class="diva" style="margin: 0 auto;" style="display: flex; " >
    
<form style="color: white; font-family: mono;" action="#" method="post">
    <div style="display: flex; justify-content: center; margin: 0 auto; border: 1px ; ">
        <select name="etapa">
            <option value="etapa1/">etapa 1</option>
            <option value="etapa2/">etapa 2</option>
            <option value="etapa3/">etapa 3</option>
        </select>

    </div><br>
    <div style="display: inline-block;" >
    atividade multipla escolha <br> <br>

    <select name="atvs" >
        <option value="atividade1.txt">
            <ul>
                <li>atividade 1</li>
            </ul>
        </option>
        <option value="atividade2.txt">
            <ul>
                <li>atividade 2</li>
            </ul>
        </option>
        <option value="atividade3.txt">
            <ul>
                <li>atividade 3</li>
            </ul>
        </option>
        
    </select>

   <!-- <input type="text" name="atividade"> <br><br>
    conteúdo: --> <br><br>
    <div>
    pergunta: <br>
    <input type="text" name="pergunta"> <br><br>
    letra a)
    <input type="text" name="conteudoa"> <br><br>
    letra b)
    <input type="text" name="conteudob"> <br><br>
    letra c)
    <input type="text" name="conteudoc"> <br><br>
    letra d)
    <input type="text" name="conteudod"> <br><br>
</div></div> <div style=" padding: 5px; display: inline-block; margin: auto; border-left: 1px solid; ">


    atividade aberta <br><br>
    <select name="atvs2" >
        <option value="atividade1.txt">
            <ul>
                <li>atividade 1</li>
            </ul>
        </option>
        <option value="atividade2.txt">
            <ul>
                <li>atividade 2</li>
            </ul>
        </option>
        <option value="atividade3.txt">
            <ul>
                <li>atividade 3</li>
            </ul>
        </option>
        
    </select> <br><br>
<p>pergunta:</p>
<input type="text" name="pergunta2">
<br><br><br><br><br><br><br><br><br><br>
</div> <br><br><br>
   <button class="click" style="border-radius: 10px; border: 1px;" type="submit" value="enviar">salvar</button>
</form>


</div>
        <?php
    if ( $_SERVER['REQUEST_METHOD'] === "POST") {
     $etapa = $_POST['etapa'];
     $arquivo = $_POST['atvs'];
     $arquiv = $_POST['atvs2'];
     $local = $etapa . $arquivo;
     $pergunta = $_POST['pergunta'] . PHP_EOL . "<br>";
     $pergunta2 = $_POST['pergunta2'] . PHP_EOL . "<br><br>";
     $conteudoa = $_POST['conteudoa'] . PHP_EOL . "<br>";
     $conteudob = $_POST['conteudob'] . PHP_EOL . "<br>";
     $conteudoc = $_POST['conteudoc'] . PHP_EOL . "<br>";
     $conteudod = $_POST['conteudod'] . PHP_EOL . "<br><br>";

if (!is_dir($etapa)) {
    mkdir($etapa, 0777, true);
}

    file_put_contents( $local, $pergunta, FILE_APPEND);
    file_put_contents( $local, $conteudoa, FILE_APPEND);
    file_put_contents( $local, $conteudob, FILE_APPEND);
    file_put_contents( $local, $conteudoc, FILE_APPEND);
    file_put_contents( $local, $conteudod, FILE_APPEND);
    file_put_contents( $local, $pergunta2, FILE_APPEND);
}
?>
</body>
</HTML>
