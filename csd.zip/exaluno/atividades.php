
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
  <style>
   * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    </style>
  <header style="width: 100%; background-color: dimgray; color: white;">
    <h1>
      <ul>
        <li><div style=" display: flex; ">
          <!-- Logo da aplicação -->
          <img src="../source/logo.png" width="40px"> CLASS DATA
       </div> </li>
      </ul>
    </h1>
    <!-- Link para voltar ao painel -->
    <a href="../painel.php" style="color: white;">voltar</a>
  </header> <br><br><br>
    <div class="diva">
        <form action="#" method="post">
        <div class="divb">
          <select name="etapa">
            <option value="etapa1/">etapa 1</option>
            <option value="etapa2/">etapa 2</option>
            <option value="etapa3/">etapa 3</option>
          </select>
        <br><br><br>

        <select name="atvs">
          <option value="atividade1.txt">atividade 1</option>
          <option value="atividade2.txt">atividade 2</option>
          <option value="atividade3.txt">atividade 3</option>
        </select>
            <button type="submit">ver atividade</a>
        </div></form>
    </div> <br>
    <br> 
    <h2 style="color: aliceblue;">
        ATIVIDADES
    </h2>
    <br>
    <div style=" padding: 10%;"> 
       <div style=" padding: 10%; text-align: left; border-radius: 2px ; background-color: white;">
        <div style="background-color: green;"><?//htmlspecialchars($atvs)?></div>

        <?php        
            if($_SERVER['REQUEST_METHOD'] ==="POST"){
               $etapa = $_POST['etapa'];
               $atvs = $_POST['atvs'];
               $local = $etapa . $atvs;             
                $conteudo = file_get_contents($local);
                echo $conteudo;
            }
        ?>

       </div>
    </div>
</body>
</html>