<?php
    echo file_get_contents("atividade1.txt");
?>