<?php
// Lê o arquivo 'dados.txt' e armazena as linhas em um array
$linhas = file('dados.txt');
?>

<!-- HTML para exibir os dados dos alunos -->
<!DOCTYPE html>
<html>
<head>
  <!-- Link para o arquivo de estilo CSS -->
  <link rel="stylesheet" href="../style.css">
  <meta charset="UTF-8">
  <title>dados dos alunos</title>
  <style>
    /* Estilos para a tabela e elementos */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    table {
      border-collapse: collapse;
    }
    th, td {
      padding: 8px;
      border: 1px solid #ccc;
    }
    .correcao {
      color: orange;
      font-size: 12px;
    }
    .erro {
      color: red;
      font-size: 12px;
    }
  </style>
</head>
<body style="background-color: aquamarine;">
  <!-- Cabeçalho com logo e link para voltar -->
  <header style="width: 100%; background-color: dimgray;">
    <h1>
      <ul>
        <li>
          <!-- Logo da aplicação -->
          <img src="../source/logo.png" width="40px"> CLASS DATA
        </li>
      </ul>
    </h1>
    <!-- Link para voltar ao painel -->
    <a href="../painel.php" style="color: white;">voltar</a>
  </header>
  <h1>DADOS DOS ALUNOS</h1>
  <!-- Tabela para exibir os dados dos alunos -->
  <table>
    <tr>
      <th>Nome</th>
      <th>nota <br> 1 etapa</th>
      <th>nota <br> 2 etapa </th>
      <th>prova multi</th>
      <th>nota <br> 3 etapa </th>
      <th>total</th>
      <th>estado</th>
      <th>faltas</th>
      <th>edição</th>
    </tr>
    <?php foreach ($linhas as $index => $linha): ?>
      <?php
      // Divide a linha em campos
      $campos = explode(";", trim($linha));
      if (count($campos) === 6) {
        // Atribui os valores dos campos às variáveis
        list($nome, $nota1, $nota2, $multi, $nota3, $faltas) = $campos;
        $msg = '';
      }
      ?>
      <?php
      // Calcula o total e a média
      $total = ($nota1 + $nota2 + $multi + $nota3);
      // Verifica se o aluno está aprovado ou em recuperação
      if ($total <= 59) {
        $media = "recuperação";
      } else {
        $media = "aprovado";
      }
      ?>
      <tr>
        <!-- Exibe os dados do aluno -->
        <td><?= htmlspecialchars($nome) ?></td>
        <td><?= htmlspecialchars($nota1) ?></td>
        <td><?= htmlspecialchars($nota2) ?></td>
        <td><?= htmlspecialchars($multi) ?></td>
        <td><?= htmlspecialchars($nota3) ?></td>
        <td><?= htmlspecialchars($total) ?></td>
        <td><?= htmlspecialchars($media) ?></td>
        <td><?= htmlspecialchars($faltas) ?></td>
        <td>
          <!-- Link para editar os dados do aluno -->
          <a href="editor.php?id=<?= $index ?>">Editar</a><br>
          <?= $msg ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</body>
</html>










<?php
$linhas = file('dados.txt');
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../style.css">
    <meta charset="UTF-8">
    <title>dados dos alunos</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        table { border-collapse: collapse; }
        th, td { padding: 8px; border: 1px solid #ccc; }
        .correcao { color: orange; font-size: 12px; }
        .erro { color: red; font-size: 12px; }
    </style>
</head>
<body style="background-color: aquamarine;">
<header style=" width: 100%; background-color: dimgray;">
    <h1>
        <ul>
            <li>
                <img src="../source/logo.png" width="40px">
                CLASS DATA
            </li>
        </ul>
    </h1>
        <a href="../painel.php" style="color: white;">voltar</a>
</header>
    <h1>DADOS DOS ALUNOS</h1>
    <table>
        <th colspan="9">NOME DA MATÉRIA</th>
        <tr>
            <th>Nome</th>
            <th>nota <br> 1 etapa</th>
            <th>nota <br> 2 etapa </th>
            <th>prova multi</th>
            <th>nota <br> 3 etapa </th>
            <th>total</th>
            <th>estado</th>
            <th>faltas</th>
            <th>edição</th>
        </tr>
        <?php foreach ($linhas as $index => $linha): ?>
            <?php
                $campos = explode(";", trim($linha));
                if (count($campos) === 6) {
                    list($nome, $nota1, $nota2, $multi, $nota3, $faltas) = $campos;
                    $msg = '';
                }
            ?>
            <?php $faltas ?>
            <?php $total = ($nota1 + $nota2 + $multi + $nota3);?>
            <?php $media = ($nota1 + $nota2 + $multi + $nota3);
            if($media<=59){
                $media = "recuperação";
            }else {
                $media = "aprovado";
            }
            ?>
            <tr>
                <td><?= htmlspecialchars($nome) ?></td>
                <td><?= htmlspecialchars($nota1) ?></td>
                <td><?= htmlspecialchars($nota2) ?></td>
                <td><?= htmlspecialchars($multi) ?></td>
                <td><?= htmlspecialchars($nota3) ?></td>
                <td><?= htmlspecialchars($total) ?></td>
                <td><?= htmlspecialchars($media) ?></td>
                <td><?= htmlspecialchars($faltas) ?></td>
                <td><a href="editor.php?id=<?= $index ?>">Editar</a><br>
                    <?= $msg ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>