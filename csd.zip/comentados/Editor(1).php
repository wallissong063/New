<?php
// Define o arquivo de dados
$arquivo = 'dados.txt';

// Lê o arquivo de dados e armazena as linhas em um array
$linhas = file($arquivo);

// Obtém o ID da linha a ser editada
$id = isset($_GET['id']) ? (int) $_GET['id'] : -1;

// Verifica se o ID é válido e se a linha existe
if ($id >= 0 && isset($linhas[$id])) {
  // Divide a linha em campos
  list($nome, $nota1, $nota2, $multi, $nota3, $faltas) = explode(";", trim($linhas[$id]));

  // Verifica se o formulário foi enviado
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtém os novos valores dos campos
    $novo_nome = $_POST['nome'];
    $nova_nota1 = $_POST['nota1'];
    $nova_nota2 = $_POST['nota2'];
    $nova_multi = $_POST['multi'];
    $nova_nota3 = $_POST['nota3'];
    $nova_faltas = $_POST['faltas'];

    // Atualiza a linha com os novos valores
    $linhas[$id] = "$novo_nome;$nova_nota1;$nova_nota2;$nova_multi;$nova_nota3;$nova_faltas\n";

    // Salva as alterações no arquivo
    file_put_contents($arquivo, implode('', $linhas));

    // Redireciona para a página de leitura
    header("Location: leitor.php");
    exit;
  }
} else {
  // Se o ID for inválido, exibe uma mensagem de erro
  die("Linha inválida!");
}
?>

<!-- HTML para exibir o formulário de edição -->
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Editar Linha</title>
</head>
<body>
  <h1>aluno numero <?= $id + 1 ?></h1>
  <form method="post">
    aluno: <input type="text" name="nome" value="<?= htmlspecialchars($nome) ?>"><br><br>
    nota 1 etapa: <input type="number" name="nota1" max="25" min="0" value="<?= htmlspecialchars($nota1) ?>"><br><br>
    nota 2 etapa: <input type="number" name="nota2" max="25" min="0" value="<?= htmlspecialchars($nota2) ?>"><br><br>
    prova multi: <input type="number" name="multi" max="15" min="0" value="<?= htmlspecialchars($multi) ?>"><br><br>
    nota 3 etapa: <input type="number" name="nota3" max="30" min="0" value="<?= htmlspecialchars($nota3) ?>"><br><br>
    faltas: <input type="number" name="faltas" min="0" value="<?= htmlspecialchars($faltas) ?>" required><br><br>
    <button type="submit">Salvar</button>
  </form>
  <br>
  <a href="leitor.php">Voltar</a>
</body>
</html>