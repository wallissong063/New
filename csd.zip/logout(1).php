<!--Inicia a sessão PHP
<?php session_start();

  //Destrói a sessão atual, removendo todas as variáveis de sessão
  session_destroy();

  //Redireciona o usuário para a página "exaluno/index.php"
  header("Location: exaluno/index.php");

  //Encerra o script PHP atual
  exit;
?>