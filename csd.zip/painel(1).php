<?php
$usuario= "";
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: painel.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <title>Painel</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        td{
            size: 20px;
        }
        .click{
            text-decoration: none;
            color: green;
            font-size: 25px;
        }
        .tfont{
            font-size: 15px;
        }
    </style>
</head>
<body>
    
    <header style="background-color: dimgray;">
      <h1  class="pr">CLASS DATA </h1>
<details style="display: flex;">
        <summary>informações</summary>
      <br><h3><a href="sobre.html">sobre</a></h3>
            
    </h3>
    </details>
    </header> 
    <h2 style="color: aliceblue;">Bem-vinda, <?= htmlspecialchars($_SESSION["usuario"]) ?>!</h2>
    <div class="" style="display: flex;" >
        <div class="diva" style="display:inline-block;">
            <a class="click" href="exaluno/leitor.php">dados de alunos</a><br><br><br>
            <a class="click" href="exaluno/adicionar.php">lançar atividade</a><br><br><br>
            <a class="click" href="exaluno/select3.html">atividades</a><br><br><br>
        </div>
        <div style=" padding: 10%; border: 1px; display: flex; justify-content: center;" >
            <p><a class="click" href="logout.php">Sair</a></p> <br><br><br>
            
        </div>
    </div>
</body>
</html>