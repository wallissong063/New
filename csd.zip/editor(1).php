<?php
$arquivo = 'dados.txt';
$linhas = file($arquivo);
$id = isset($_GET['id']) ? (int) $_GET['id'] : -1;

if ($id >= 0 && isset($linhas[$id])) {
    list($nome, $nota, $falta) = explode(";", trim($linhas[$id]));

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $novo_nome = $_POST['nome'];
        $nova_nota = $_POST['nota'];
        $nova_falta = $_POST['falta'];

        $linhas[$id] = "$novo_nome;$nova_nota;$nova_falta\n";
        file_put_contents($arquivo, implode('', $linhas));

        header("Location: exaluno/visualizar.php");
        exit;
    }
} else {
    die("Linha inválida!");
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editar Linha <?= $id + 1 ?></title>
    <style>
        body{
            background-color: red;
        }
    </style>
</head>
<body>
    <h1>Editando Linha <?= $id + 1 ?></h1>
    <form method="post">
        Nome: <input type="text" name="nome" value="<?= htmlspecialchars($nome) ?>" required><br><br>
        nota: <input type="number" name="nota" value="<?= htmlspecialchars($nota) ?>" required><br><br>
        falta: <input type="number" name="falta" value="<?= htmlspecialchars($falta) ?>" required><br><br>
        <button type="submit">Salvar</button>
    </form>
    <br>
    <a href="exaluno/visualizar.php">Voltar</a>
</body>
</html>