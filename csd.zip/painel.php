<?php
$usuario= "";
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: painel.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <title>Painel</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        td{
            size: 20px;
        }
    </style>
</head>
<body>
    
    <header style="background-color: dimgray;">
      <h1  class="pr"><img src="source/logo.png" width="32px">CLASS DATA </h1>
<details style="display: flex;">
        <summary>informações</summary>
      <br>
      <ul>
        <li>
            <a href="sobre.html">sobre</a>
        </li>
      </ul>
        
    </h3>
    </details>
    </header> 
    <h2 style="color: aliceblue;">Bem-vinda, <?= htmlspecialchars($_SESSION["usuario"]) ?>!</h2>
    <div class="diva" style="display: flex;" >
        <div class="diva" style="display:inline-block;">
            <a href="exaluno/leitor.php">dados de alunos</a><br><br><br>
            <a href="exaluno/adicionar.php">lançar atividade</a><br><br><br>
            <a href="exaluno/select3.html">atividades</a><br><br><br>
            <a href="exaluno/.php">***</a><br><br><br>
        </div>
        <div style=" padding: 10%; border: 1px; display: flex; justify-content: center;" >
            <p><a class="click" href="logout.php">Sair</a></p> <br><br><br>
            
        </div>
    </div>
</body>
</html>