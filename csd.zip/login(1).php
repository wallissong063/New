<?php
// Inicia a sessão PHP para armazenar dados do usuário
session_start();

// Define uma mensagem inicial para exibir ao usuário
$mensagem = "";

// Verifica se o formulário foi enviado via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  // Obtém os valores de usuário e senha do formulário
  $usuario = $_POST["usuario"] ?? "";
  $senha = $_POST["senha"] ?? "";

  // Verifica se o arquivo de usuários existe
  if (!file_exists("usuarios.txt")) {
    // Se não existe, define uma mensagem de erro
    $mensagem = "usuários não encontrados";
  } else {
    // Lê o arquivo de usuários e ignora linhas vazias
    $usuarios = file("usuarios.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Variável para indicar se o usuário foi encontrado
    $encontrado = false;

    // Percorre cada linha do arquivo de usuários
    foreach ($usuarios as $linha) {
      // Divide a linha em usuário e senha
      list($user, $pass) = explode(":", $linha);

      // Verifica se o usuário e senha coincidem
      if ($usuario === trim($user) && $senha === trim($pass)) {
        // Se coincidem, define a variável de sessão e redireciona para o painel
        $encontrado = true;
        $_SESSION["usuario"] = $usuario;
        break;
      }
    }

    // Se o usuário foi encontrado, redireciona para o painel
    if ($encontrado) {
      header("Location: painel.php");
      exit;
    } else {
      // Se não foi encontrado, define uma mensagem de erro
      $mensagem = "Usuário ou senha inválidos.";
    }
  }
}
?>

<!-- HTML para exibir a mensagem de erro -->
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="style.css">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>login</title>
</head>
<body>
  <!-- Exibe a mensagem de erro -->
  <p style="color: red;" class="text-error" >email ou senha invalidos ;-;</p>
  <br>
  <!-- Link para voltar à página anterior -->
  <a href="exaluno/index.php" class="click" >voltar</a>
</body>
</html>